#!/bin/bash
# GIST analysis only - uses existing MD trajectory

set -e

echo "=========================================="
echo "Starting GIST analysis at $(date)"
echo "=========================================="

# Check if required files exist
if [ ! -f "rbp4.prmtop" ] || [ ! -f "mdcrd.nc" ]; then
    echo "ERROR: rbp4.prmtop or mdcrd.nc not found"
    exit 1
fi

echo ""
echo "[Step 1] Running GIST analysis..."

cat > gist.in << 'EOF'
parm rbp4.prmtop
trajin mdcrd.nc
autoimage
reference equil.rst
rms !:WAT reference
gist refdens 0.0334 gridcntr -9.23 -3.06 1.41 griddim 60 60 60 out gist.out
go
EOF

cpptraj -i gist.in
if [ $? -ne 0 ]; then
    echo "ERROR: GIST analysis failed. Check gist.out"
    exit 1
fi
echo "GIST analysis completed"

echo ""
echo "=========================================="
echo "GIST ANALYSIS COMPLETED SUCCESSFULLY at $(date)"
echo "=========================================="
echo ""
echo "Generated files:"
ls -lh gist*.dx 2>/dev/null
echo ""
