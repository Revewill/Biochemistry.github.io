There are three folders in current directory.

(1) Folder "/Program" includes the executable files of the HydraMap-v2.
The specific process for predicting hydration sites is as follows:

Step 1:
         ./wsitem  protein_file ligand_file  apo/holo  [D]  [Ecut]  [radius]  [N]
Here, the protein file and ligand file adopt PDB format and MOL2 format, respectively;
apo/holo:  predict hydration sites in the apo or holo state of the protein;
D:  the dimension length of the grid box for hydration site prediction, recommend: 3.0;
Ecut: the energy cutoff to define the favorable water probes in hydration site prediction,  recommend: 3.0;
radius: the parameter used in a clustering based on ShiftMean algorithm, recommend: 2.0;
N:  the minimal number grids in a cluster to define a valid hydration site, recommend: 10;

This step will generate the original output of the predicted hydration sites in apo or holo state of the protein.
Output file:    XXXX_apo_ws.pdb
                     XXXX_holo_ws.pdb

Step 2:
         ./getwat  protein_file  ligand_file  wat_file  [ distance ]
This command is used to select crystal water molecules/predicted hydration sites within a distance threshold 
of the ligand. The recommended value of "distance" is 5.0.
Rename the output file as:  XXXX_apo_ws-5A.pdb  / XXXX_holo_ws-5A.pdb

Step 3: 
         ./wnmin    protein_file  water_file  [step]
         ./wnmin2  protein_file ligand_file water_file  [step]
These two commands are used to optimize the water network obtained from the apo and holo states of the protein.
step: recommend, 100.
water_file:  XXXX_apo_ws-5A.pdb      XXXX_holo_ws-5A.pdb
Rename the output files as :  XXXX_apo_min-5A.pdb      XXXX_holo_min-5A.pdb

Step 4:
         ./analws  protein_file  ligand_file  wat_apo  wat_holo
This command is used to compare the hydration sites predicted by the apo and holo states of the same protein.
It will output three types of "displaced hydration site", "matched hydration site/conserved hydration site" and "shifted hydration site" with their energies.

(2) Folder "/MCL-1" includes files for retrospective validation on MCL-1.
Subfolder "ligand_dock" includes four ligand files after molecular docking. 
1.mol2 (YCW-E10)  2.mol2 (FWJ-D4)  3.mol2 (FWJ-D5)   4.mol2 (FWJ-D6)

Subfolder "hydration_site_file" includes the original files, the truncated original files and the optimized truncated files of the hydration sites.

(3) Folder "/Six_test_set" includes six subfolders "BACE1", "BRD4", "CFD", "FIXa", "HSP90" and "MUP".
In each subfolder, the docked ligand files, original files of hydration sites are provided.
